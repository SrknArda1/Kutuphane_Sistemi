<?php $__env->startSection('title', 'Yeni Ödünç — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Yeni Ödünç Ekle</h1>

    <form action="<?php echo e(route('oduncler.store')); ?>" method="POST" class="form">
        <?php echo csrf_field(); ?>

        <div class="form-grup">
            <label for="uye_id">Üye <span class="zorunlu">*</span></label>
            <select id="uye_id" name="uye_id" required>
                <option value="">— Üye seçin —</option>
                <?php $__currentLoopData = $uyeler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($uye->id); ?>" <?php if(old('uye_id') == $uye->id): echo 'selected'; endif; ?>>
                        <?php echo e($uye->ad); ?> <?php echo e($uye->soyad); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['uye_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="kitap_id">Kitap <span class="zorunlu">*</span></label>
            <select id="kitap_id" name="kitap_id" required>
                <option value="">— Kitap seçin —</option>
                <?php $__currentLoopData = $kitaplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kitap->id); ?>" <?php if(old('kitap_id') == $kitap->id): echo 'selected'; endif; ?>>
                        <?php echo e($kitap->baslik); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['kitap_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="odunc_tarihi">Ödünç Tarihi <span class="zorunlu">*</span></label>
            <input type="date" id="odunc_tarihi" name="odunc_tarihi" value="<?php echo e(old('odunc_tarihi')); ?>" required>
            <?php $__errorArgs = ['odunc_tarihi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="beklenen_iade_tarihi">Beklenen İade Tarihi <span class="zorunlu">*</span></label>
            <input type="date" id="beklenen_iade_tarihi" name="beklenen_iade_tarihi" value="<?php echo e(old('beklenen_iade_tarihi')); ?>" required>
            <?php $__errorArgs = ['beklenen_iade_tarihi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="iade_tarihi">İade Tarihi</label>
            <input type="date" id="iade_tarihi" name="iade_tarihi" value="<?php echo e(old('iade_tarihi')); ?>">
            <?php $__errorArgs = ['iade_tarihi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="durum">Durum <span class="zorunlu">*</span></label>
            <select id="durum" name="durum" required>
                <option value="aktif" <?php if(old('durum', 'aktif') === 'aktif'): echo 'selected'; endif; ?>>Aktif</option>
                <option value="iade_edildi" <?php if(old('durum') === 'iade_edildi'): echo 'selected'; endif; ?>>İade Edildi</option>
            </select>
            <?php $__errorArgs = ['durum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-aksiyon">
            <button type="submit" class="btn btn-birincil">Kaydet</button>
            <a href="<?php echo e(route('oduncler.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/oduncler/create.blade.php ENDPATH**/ ?>