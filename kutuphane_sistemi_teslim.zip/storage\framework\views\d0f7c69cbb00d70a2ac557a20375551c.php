<?php $__env->startSection('title', 'Kategoriler — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Kategoriler</h1>

    <?php if(session('basari')): ?>
        <div class="mesaj mesaj-basari"><?php echo e(session('basari')); ?></div>
    <?php endif; ?>

    <?php if(session('hata')): ?>
        <div class="mesaj mesaj-hata"><?php echo e(session('hata')); ?></div>
    <?php endif; ?>

    <p class="ust-arac">
        <a href="<?php echo e(route('kategoriler.create')); ?>" class="btn btn-birincil">Yeni Kategori Ekle</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>Ad</th>
                <th>Açıklama</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($kategori->ad); ?></td>
                    <td><?php echo e($kategori->aciklama ?? '—'); ?></td>
                    <td class="islem-hucre">
                        <a href="<?php echo e(route('kategoriler.edit', $kategori)); ?>" class="btn btn-kucuk">Düzenle</a>
                        <form action="<?php echo e(route('kategoriler.destroy', $kategori)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-kucuk btn-tehlike" onclick="return confirm('Bu kategoriyi silmek istediğinize emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">Kategori yok</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/kategoriler/index.blade.php ENDPATH**/ ?>