<?php $__env->startSection('title', 'Yeni Kitap — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Yeni Kitap Ekle</h1>

    <form action="<?php echo e(route('kitaplar.store')); ?>" method="POST" class="form">
        <?php echo csrf_field(); ?>

        <div class="form-grup">
            <label for="kategori_id">Kategori <span class="zorunlu">*</span></label>
            <select id="kategori_id" name="kategori_id" required>
                <option value="">— Kategori seçin —</option>
                <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kategori->id); ?>" <?php if(old('kategori_id') == $kategori->id): echo 'selected'; endif; ?>>
                        <?php echo e($kategori->ad); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="baslik">Başlık <span class="zorunlu">*</span></label>
            <input type="text" id="baslik" name="baslik" value="<?php echo e(old('baslik')); ?>" required>
            <?php $__errorArgs = ['baslik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="yazar">Yazar <span class="zorunlu">*</span></label>
            <input type="text" id="yazar" name="yazar" value="<?php echo e(old('yazar')); ?>" required>
            <?php $__errorArgs = ['yazar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="isbn">ISBN</label>
            <input type="text" id="isbn" name="isbn" value="<?php echo e(old('isbn')); ?>">
        </div>

        <div class="form-grup">
            <label for="yayin_yili">Yayın Yılı <span class="zorunlu">*</span></label>
            <input type="number" id="yayin_yili" name="yayin_yili" value="<?php echo e(old('yayin_yili')); ?>" required>
            <?php $__errorArgs = ['yayin_yili'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="stok_adedi">Stok Adedi <span class="zorunlu">*</span></label>
            <input type="number" id="stok_adedi" name="stok_adedi" value="<?php echo e(old('stok_adedi', 1)); ?>" min="0" required>
            <?php $__errorArgs = ['stok_adedi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-aksiyon">
            <button type="submit" class="btn btn-birincil">Kaydet</button>
            <a href="<?php echo e(route('kitaplar.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/kitaplar/create.blade.php ENDPATH**/ ?>