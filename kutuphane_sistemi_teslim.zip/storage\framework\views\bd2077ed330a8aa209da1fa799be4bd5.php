<?php $__env->startSection('title', 'Üyeler — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Üyeler</h1>

    <?php if(session('basari')): ?>
        <div class="mesaj mesaj-basari"><?php echo e(session('basari')); ?></div>
    <?php endif; ?>

    <?php if(session('hata')): ?>
        <div class="mesaj mesaj-hata"><?php echo e(session('hata')); ?></div>
    <?php endif; ?>

    <p class="ust-arac">
        <a href="<?php echo e(route('uyeler.create')); ?>" class="btn btn-birincil">Yeni Üye Ekle</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>Ad Soyad</th>
                <th>E-posta</th>
                <th>Telefon</th>
                <th>Kayıt Tarihi</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $uyeler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($uye->ad); ?> <?php echo e($uye->soyad); ?></td>
                    <td><?php echo e($uye->email); ?></td>
                    <td><?php echo e($uye->telefon ?? '—'); ?></td>
                    <td><?php echo e($uye->kayit_tarihi->format('d.m.Y')); ?></td>
                    <td class="islem-hucre">
                        <a href="<?php echo e(route('uyeler.edit', $uye)); ?>" class="btn btn-kucuk">Düzenle</a>
                        <form action="<?php echo e(route('uyeler.destroy', $uye)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-kucuk btn-tehlike" onclick="return confirm('Bu üyeyi silmek istediğinize emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">Üye yok</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/uyeler/index.blade.php ENDPATH**/ ?>