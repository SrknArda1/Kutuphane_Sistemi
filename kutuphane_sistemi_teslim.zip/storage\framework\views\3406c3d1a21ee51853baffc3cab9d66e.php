<?php $__env->startSection('title', 'Üye Düzenle — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Üye Düzenle</h1>

    <form action="<?php echo e(route('uyeler.update', $uye)); ?>" method="POST" class="form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-grup">
            <label for="ad">Ad <span class="zorunlu">*</span></label>
            <input type="text" id="ad" name="ad" value="<?php echo e(old('ad', $uye->ad)); ?>" required>
            <?php $__errorArgs = ['ad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="soyad">Soyad <span class="zorunlu">*</span></label>
            <input type="text" id="soyad" name="soyad" value="<?php echo e(old('soyad', $uye->soyad)); ?>" required>
            <?php $__errorArgs = ['soyad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="email">E-posta <span class="zorunlu">*</span></label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email', $uye->email)); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="telefon">Telefon</label>
            <input type="text" id="telefon" name="telefon" value="<?php echo e(old('telefon', $uye->telefon)); ?>">
        </div>

        <div class="form-grup">
            <label for="kayit_tarihi">Kayıt Tarihi <span class="zorunlu">*</span></label>
            <input type="date" id="kayit_tarihi" name="kayit_tarihi" value="<?php echo e(old('kayit_tarihi', $uye->kayit_tarihi->format('Y-m-d'))); ?>" required>
            <?php $__errorArgs = ['kayit_tarihi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-aksiyon">
            <button type="submit" class="btn btn-birincil">Güncelle</button>
            <a href="<?php echo e(route('uyeler.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/uyeler/edit.blade.php ENDPATH**/ ?>