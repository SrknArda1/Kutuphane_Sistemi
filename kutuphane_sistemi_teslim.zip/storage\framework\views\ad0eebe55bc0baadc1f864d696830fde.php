<?php $__env->startSection('title', 'Kitaplar — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Kitaplar</h1>

    <?php if(session('basari')): ?>
        <div class="mesaj mesaj-basari"><?php echo e(session('basari')); ?></div>
    <?php endif; ?>

    <?php if(session('hata')): ?>
        <div class="mesaj mesaj-hata"><?php echo e(session('hata')); ?></div>
    <?php endif; ?>

    <p class="ust-arac">
        <a href="<?php echo e(route('kitaplar.create')); ?>" class="btn btn-birincil">Yeni Kitap Ekle</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>Başlık</th>
                <th>Yazar</th>
                <th>Kategori</th>
                <th>ISBN</th>
                <th>Yayın Yılı</th>
                <th>Stok</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kitaplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($kitap->baslik); ?></td>
                    <td><?php echo e($kitap->yazar); ?></td>
                    <td><?php echo e($kitap->kategori->ad); ?></td>
                    <td><?php echo e($kitap->isbn ?? '—'); ?></td>
                    <td><?php echo e($kitap->yayin_yili); ?></td>
                    <td><?php echo e($kitap->stok_adedi); ?></td>
                    <td class="islem-hucre">
                        <a href="<?php echo e(route('kitaplar.edit', $kitap)); ?>" class="btn btn-kucuk">Düzenle</a>
                        <form action="<?php echo e(route('kitaplar.destroy', $kitap)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-kucuk btn-tehlike" onclick="return confirm('Bu kitabı silmek istediğinize emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Kitap yok</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/kitaplar/index.blade.php ENDPATH**/ ?>