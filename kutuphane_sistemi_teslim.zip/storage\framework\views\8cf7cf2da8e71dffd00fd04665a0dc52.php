<?php $__env->startSection('title', 'Raporlar — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Raporlar</h1>

    
    <section>
        <h2>Üye-Kitap Ödünç Listesi</h2>

        <table>
            <thead>
                <tr>
                    <th>Üye Adı</th>
                    <th>Kitap</th>
                    <th>Ödünç Tarihi</th>
                    <th>Beklenen İade</th>
                    <th>Durum</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $oduncListesi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odunc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($odunc->uye->ad); ?> <?php echo e($odunc->uye->soyad); ?></td>
                        <td><?php echo e($odunc->kitap->baslik); ?></td>
                        <td><?php echo e($odunc->odunc_tarihi->format('d.m.Y')); ?></td>
                        <td><?php echo e($odunc->beklenen_iade_tarihi->format('d.m.Y')); ?></td>
                        <td>
                            <?php if($odunc->durum === 'aktif'): ?>
                                <span class="durum-aktif">Aktif</span>
                            <?php else: ?>
                                <span class="durum-iade">İade Edildi</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">Kayıt bulunamadı</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    
    <section>
        <h2>Kategoriye Göre Kitap Sayısı</h2>

        <table>
            <thead>
                <tr>
                    <th>Kategori</th>
                    <th>Kitap Sayısı</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kategoriIstatistik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($kategori->ad); ?></td>
                        <td><?php echo e($kategori->kitaplar_count); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2">Kayıt bulunamadı</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    
    <section>
        <h2>En Az 3 Kitap Ödünç Almış Üyeler</h2>

        <table>
            <thead>
                <tr>
                    <th>Ad Soyad</th>
                    <th>Ödünç Sayısı</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $aktifUyeler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($uye->ad); ?> <?php echo e($uye->soyad); ?></td>
                        <td><?php echo e($uye->oduncler_count); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2">Kayıt bulunamadı</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/raporlar/index.blade.php ENDPATH**/ ?>