<?php $__env->startSection('title', 'Ödünçler — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Ödünçler</h1>

    <?php if(session('basari')): ?>
        <div class="mesaj mesaj-basari"><?php echo e(session('basari')); ?></div>
    <?php endif; ?>

    <?php if(session('hata')): ?>
        <div class="mesaj mesaj-hata"><?php echo e(session('hata')); ?></div>
    <?php endif; ?>

    <p class="ust-arac">
        <a href="<?php echo e(route('oduncler.create')); ?>" class="btn btn-birincil">Yeni Ödünç Ekle</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>Üye</th>
                <th>Kitap</th>
                <th>Ödünç Tarihi</th>
                <th>Beklenen İade</th>
                <th>İade Tarihi</th>
                <th>Durum</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $oduncler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odunc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($odunc->uye->ad); ?> <?php echo e($odunc->uye->soyad); ?></td>
                    <td><?php echo e($odunc->kitap->baslik); ?></td>
                    <td><?php echo e($odunc->odunc_tarihi->format('d.m.Y')); ?></td>
                    <td><?php echo e($odunc->beklenen_iade_tarihi->format('d.m.Y')); ?></td>
                    <td><?php echo e($odunc->iade_tarihi ? $odunc->iade_tarihi->format('d.m.Y') : '—'); ?></td>
                    <td>
                        <?php if($odunc->durum === 'aktif'): ?>
                            <span class="durum-aktif">Aktif</span>
                        <?php else: ?>
                            <span class="durum-iade">İade Edildi</span>
                        <?php endif; ?>
                    </td>
                    <td class="islem-hucre">
                        <a href="<?php echo e(route('oduncler.edit', $odunc)); ?>" class="btn btn-kucuk">Düzenle</a>
                        <form action="<?php echo e(route('oduncler.destroy', $odunc)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-kucuk btn-tehlike" onclick="return confirm('Bu ödünç kaydını silmek istediğinize emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Ödünç kaydı yok</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/oduncler/index.blade.php ENDPATH**/ ?>