<?php $__env->startSection('title', 'Kategori Düzenle — Kütüphane Sistemi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Kategori Düzenle</h1>

    <form action="<?php echo e(route('kategoriler.update', $kategori)); ?>" method="POST" class="form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-grup">
            <label for="ad">Ad <span class="zorunlu">*</span></label>
            <input type="text" id="ad" name="ad" value="<?php echo e(old('ad', $kategori->ad)); ?>" required>
            <?php $__errorArgs = ['ad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="form-hata"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grup">
            <label for="aciklama">Açıklama</label>
            <textarea id="aciklama" name="aciklama" rows="4"><?php echo e(old('aciklama', $kategori->aciklama)); ?></textarea>
        </div>

        <div class="form-aksiyon">
            <button type="submit" class="btn btn-birincil">Güncelle</button>
            <a href="<?php echo e(route('kategoriler.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Desktop\kutuphane_sistemi\resources\views/kategoriler/edit.blade.php ENDPATH**/ ?>